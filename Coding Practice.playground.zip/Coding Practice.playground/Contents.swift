import UIKit


import Foundation

func palindromeIndex(s: String) -> Int {
    let characters = Array(s)
    let length = characters.count

    func isPalindrome(_ arr: [Character]) -> Bool {
        return arr == arr.reversed()
    }

    if isPalindrome(characters) {
        return -1
    }

    var left = 0
    var right = length - 1

    while left < right {
        if characters[left] != characters[right] {
            // Check by removing the character at the left index
            if isPalindrome(Array(characters[left + 1...right])) {
                return left
            }
            // Check by removing the character at the right index
            if isPalindrome(Array(characters[left...right - 1])) {
                return right
            }
            return -1
        }
        left += 1
        right -= 1
    }

    return -1
}

// Example usage:
let queries = ["aaab", "baa", "aaa"]
for s in queries {
    print(palindromeIndex(s: s))
}
